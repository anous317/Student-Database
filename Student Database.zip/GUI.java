import javax.swing.*;
import javax.xml.stream.XMLStreamException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;

public class GUI {
    public void interfaccia() {

        JFrame frame = new JFrame("Student Database");
        JPanel panel = new JPanel(new BorderLayout());

        StudentManager sm = new StudentManager();
        StudentTableModel stm = new StudentTableModel();
        JTable table = new JTable(stm);
        JScrollPane scrollPane = new JScrollPane(table);
        table.setBackground(new Color(255, 253, 208));

        JLabel label = new JLabel("LISTA STUDENTI", SwingConstants.CENTER);

        panel.add(label, BorderLayout.NORTH);


        panel.add(scrollPane, BorderLayout.CENTER);


        JPanel inputPanel = new JPanel(new FlowLayout());
        JTextField nomeField = new JTextField(10);
        JTextField cognomeField = new JTextField(10);
        JTextField emailField = new JTextField(10);
        JTextField phoneField = new JTextField(10);
        JTextField birthdayField = new JTextField(10);

        JButton button = new JButton("ADD");
        button.setBackground(Color.GREEN);
        JButton remove = new JButton("REMOVE");
        remove.setBackground(Color.RED);

        inputPanel.add(new JLabel("Name:"));
        inputPanel.add(nomeField);
        inputPanel.add(new JLabel("Surname:"));
        inputPanel.add(cognomeField);
        inputPanel.add(new JLabel("Email:"));
        inputPanel.add(emailField);
        inputPanel.add(new JLabel("Phone:"));
        inputPanel.add(phoneField);
        inputPanel.add(new JLabel("Birthday:"));
        inputPanel.add(birthdayField);
        inputPanel.add(button);
        inputPanel.add(remove);

        inputPanel.setBackground(new Color(255,253, 208));

        panel.add(inputPanel, BorderLayout.SOUTH);
        panel.setBackground(Color.YELLOW);

        remove.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stm.removeLastStudent();

            }
        });

        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nomeField.getText().trim();
                String surname = cognomeField.getText().trim();
                String email = emailField.getText().trim();
                String phone = phoneField.getText().trim();
                String birthday = birthdayField.getText().trim();

                Student studente = null;
                try {
                    studente = sm.addStudent(name, surname, email, phone, birthday);
                } catch (XMLStreamException ex) {
                    throw new RuntimeException(ex);
                } catch (FileNotFoundException ex) {
                    throw new RuntimeException(ex);
                }
                stm.addRow(studente);

            }
        });

        frame.add(panel);
        frame.setSize(1000, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }
}