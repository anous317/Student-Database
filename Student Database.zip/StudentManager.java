import javax.xml.stream.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Vector;

public class StudentManager {
    Vector<Student> students = new Vector<>();

    public void xmlWriter(Vector<Student> students) throws XMLStreamException, FileNotFoundException {
        FileOutputStream fos = new FileOutputStream("students.xml");
        XMLOutputFactory xmlOutFact = XMLOutputFactory.newInstance();
        XMLStreamWriter writer = xmlOutFact.createXMLStreamWriter(fos);
        writer.writeStartDocument();
        writer.writeCharacters("\n");
        writer.writeStartElement("students");
        writer.writeCharacters("\n");

        for (Student s : students) {
            writer.writeCharacters("\t");
            writer.writeStartElement("student");
            writer.writeCharacters("\n");

            writer.writeCharacters("\t\t");
            writer.writeStartElement("name");
            writer.writeCharacters(s.getName());
            writer.writeEndElement();
            writer.writeCharacters("\n");
            writer.writeCharacters("\t\t");

            writer.writeStartElement("surname");
            writer.writeCharacters(s.getSurname());
            writer.writeEndElement();
            writer.writeCharacters("\n");
            writer.writeCharacters("\t\t");

            writer.writeStartElement("email");
            writer.writeCharacters(s.getEmail());
            writer.writeEndElement();
            writer.writeCharacters("\n");
            writer.writeCharacters("\t\t");

            writer.writeStartElement("phone");
            writer.writeCharacters(s.getPhone());
            writer.writeEndElement();
            writer.writeCharacters("\n");
            writer.writeCharacters("\t\t");

            writer.writeStartElement("birthday");
            writer.writeCharacters(s.getBirthday());
            writer.writeEndElement();
            writer.writeCharacters("\n");
            writer.writeCharacters("\t");
            writer.writeEndElement();
            writer.writeCharacters("\n");
        }
        writer.writeEndElement();
    }

    public Vector<Student> xmlReader() throws FileNotFoundException, XMLStreamException {

        FileInputStream fis = new FileInputStream("students.xml");
        XMLInputFactory xmlInFact = XMLInputFactory.newInstance();
        XMLStreamReader reader = xmlInFact.createXMLStreamReader(fis);
        Student student = null;

        while (reader.hasNext()) {
            int xmlEvent = reader.next();
            if (xmlEvent == XMLStreamConstants.START_ELEMENT) {
                if (reader.getLocalName().equals("student")) {
                    student = new Student();
                }
                if (reader.getLocalName().equals("name")) {
                    reader.next();
                    student.setName(reader.getText());
                    continue;
                }
                if (reader.getLocalName().equals("surname")) {
                    reader.next();
                    student.setSurname(reader.getText());
                    continue;
                }
                if (reader.getLocalName().equals("email")) {
                    reader.next();
                    student.setEmail(reader.getText());
                    continue;
                }
                if (reader.getLocalName().equals("phone")) {
                    reader.next();
                    student.setPhone(reader.getText());
                    continue;
                }
                if (reader.getLocalName().equals("birthday")) {
                    reader.next();
                    student.setBirthday(reader.getText());
                    continue;
                }

            }
            if (xmlEvent == XMLStreamConstants.END_ELEMENT) {
                if (reader.getLocalName().equals("student")) {
                    students.add(student);
                }
            }
        }
        System.out.println(students);
        return students;
    }

    public Student addStudent(String nome, String cognome, String email, String phone, String birthday) throws XMLStreamException, FileNotFoundException {
        Student s = new Student(nome, cognome, email, phone, birthday);
        students.add(s);
        StudentManager sm = new StudentManager();
        sm.xmlWriter(students);
        return s;

    }
}