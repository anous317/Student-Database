import javax.swing.table.AbstractTableModel;
import java.util.Vector;

public class StudentTableModel extends AbstractTableModel {
    private String[] columnNames = {"name", "surname", "email", "phone", "birthday"};
    private Vector<Student> data = new Vector<>();
    Vector<Student> students = new Vector<>();

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex)
        {
            case 0:
                return data.get(rowIndex).getName();
            case 1:
                return data.get(rowIndex).getSurname();
            case 2:
                return data.get(rowIndex).getEmail();
            case 3:
                return data.get(rowIndex).getPhone();
            case 4:
                return data.get(rowIndex).getBirthday();
            default:
                return null;
        }
    }

    public void addRow(Student student) {
        data.add(student);
        fireTableRowsInserted(data.size() - 1, data.size() - 1);
    }

    public void removeLastStudent() {
        int lastIndex = data.size() - 1;
        if (lastIndex >= 0) {
            data.remove(lastIndex);
            fireTableRowsDeleted(lastIndex, lastIndex);
        }
    }

}